const produtos = [
    
    { imagem: "https://th.bing.com/th/id/R.41bfff73a21bfa93681e14511bbaa18a?rik=IUOG5yPymiOp6A&pid=ImgRaw&r=0.jpg", nome: "ARJ Eventos |Diária| ", preco: 399.90 , descricao: "Vestido Azul tecido leve Seda Árabe Apropriado para Casamentos e Jantares de Gala. ", categoria: "Feminino",promocao: "false", subcategoria: "Roupa" },
    { imagem: "https://th.bing.com/th/id/OIP.jeh54rQ961zSbkALXf54pAHaJP?rs=1&pid=ImgDetMain.jpg", nome: "ARJ Eventos |Diária|", preco:178.90, descricao: "Vestido Rosa Rendado Apropriado para Casamentos e Jantares de Gala e Aniversários. ", categoria: "Feminino",promocao: "false", subcategoria: "Roupa" },
    { imagem: "https://i.pinimg.com/736x/98/2b/7b/982b7b753e61acd7771800bd6b3674e1.jpg", nome: "Styles Event  |Diária|", preco: 89.90, descricao: "Macacão Dourado apropriado para quem busca um estilo despojado elegante", categoria: "Feminino",promocao: "true", subcategoria: "Roupa"},
    { imagem: "https://i.pinimg.com/originals/76/cf/00/76cf0053dbe268e91ec493fd89c108b4.jpg", nome: "Invictuss |Diária|", preco: 299.90, descricao: "Confortável e Respeitável Apropriado para Todos os tipos de Eventos.",categoria: "Masculino",promocao: "false", subcategoria: "Roupa"},
    { imagem: "https://i.pinimg.com/736x/1b/46/89/1b46894940f8b1fd5481a8a0b5a3f17e--bohemian-groom-attire-summer-groom-attire.jpg", nome: "Alphas |Diária|", preco: 325.79, descricao: "Conjunto Creme Masculino Apropriado para Casamentos e Evento de Gala Tamanho M", categoria: "Masculino",promocao: "false", subcategoria: "Roupa"},
    { imagem: "https://th.bing.com/th/id/R.50c72c621dd4e326a4a5c0e7bc8368a0?rik=ZwpXawCxHEiGjg&pid=ImgRaw&r=0.jpg", nome: "Styles Event  |Diária|", preco: 289.90, descricao: "Vestido Vermelho Marsala Tubinho Apropriado para Casamentos e Jantares de Gala e Aniversários. Tamanho M", categoria: "Feminino",promocao: "false", subcategoria: "Roupa"},
    { imagem: "https://femmeverso.com.br/wp-content/uploads/2019/08/Como-acertar-usando-o-estilo-esporte-fino-3.jpg", nome: "Vicktoria |Diária|", preco: 78.90, descricao: "O macacão é elegante e sofisticado, com um corte impecável e um design moderno, ideal para ocasiões de esporte fino.",categoria: "Feminino",promocao: "true", subcategoria: "Roupa"},
    { imagem: "https://th.bing.com/th/id/OIP.DmBaeDbeXw2kOjN8JDQRRAAAAA?rs=1&pid=ImgDetMain.jpg", nome: "Alphas |Diária|", preco: 425.79, descricao: "Conjunto Azul Masculino com tênis tamanho (44) incluso. Apropriado para todas ocasiões", categoria: "Masculino",promocao: "true", subcategoria: "Roupa"},
    { imagem: "https://http2.mlstatic.com/D_NQ_NP_962959-MLB72383732455_102023-O-vestido-festa-longo-feminino-com-fenda-elegante-estiloso.webp", nome: "Vicktoria |Diária|", preco: 215.00, descricao: "O vestido longo apresenta uma fenda elegante, com um design estiloso que combina sofisticação e modernidade, ideal para eventos formais.", categoria:"Feminino", promocao:"true", subcategoria: "Roupa" },
    { imagem: "https://www.pronovias.com/media/catalog/product/a/l/alocasia_b.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=747&width=560&canvas=560:747", nome: "Styles Event  |Diária|", preco: 289.90, descricao: "O vestido é longo e elegante, com um design fluido e sofisticado, destacando a silhueta com delicados detalhes e um caimento impecável.", categoria: "Feminino",promocao: "true", subcategoria: "Roupa"},
    { imagem: "https://http2.mlstatic.com/D_NQ_NP_899088-MLB70092934939_062023-O.webp", nome: "Happy Children |Diária|", preco:158.90, descricao: "A roupa é um conjunto elegante de blusa e saia, com tecido fluido e detalhes que criam um look sofisticado e moderno.", categoria: "Infantil",promocao: "false", subcategoria: "Roupa" },
    { imagem: "https://guiaestilomasculino.com/wp-content/uploads/Esporte-fino-costume-com-camiseta-branca-768x1153.jpg", nome: "Fashion Men |Diária|", preco: 199.90, descricao: "Terno escuro de corte slim, com lapelas discretas e tecido leve, oferecendo sofisticação e conforto no estilo esporte fino.",categoria: "Masculino",promocao: "false", subcategoria: "Roupa"},
    { imagem: "https://ae01.alicdn.com/kf/S226e1123a66d442390f6b85c1bc5bdd59.jpg_640x640q90.jpg", nome: "Teen Style |Diária|", preco:178.90, descricao: "O vestido longo, de modelagem ajustada, com mangas curtas e detalhes em renda, criando um visual elegante e delicado.", categoria: "Feminino",promocao: "false", subcategoria: "Roupa" },
    { imagem: "https://th.bing.com/th/id/R.14cfa2aba5b984632e231f13d49bf787?rik=UeuI9ugROT1oyQ&pid=ImgRaw&r=0.jpg", nome: "Happy Children |Diária|", preco: 79.99, descricao: "Conjunto Infantil cinza, Apropriados para Casamentos e Grandes Eventos veste até 3 anos",categoria: "Infantil",promocao: "true", subcategoria: "Roupa"},
    { imagem: "https://th.bing.com/th/id/OIP.gXHsZke1My2bUgzEZnkk7AHaHa?rs=1&pid=ImgDetMain.jpg", nome: "Happy Children |Diária|", preco: 28.90, descricao: "Colar infantil folheado a ouro. Apropriado para crianças a partir de 10 anos",categoria: "Infantil",promocao: "false", subcategoria: "Acessorio"},
    { imagem: "https://homensquesecuidam.com/wp-content/uploads/2020/11/colares-masculinos-em-alta-por-juan-alves-homens-que-se-cuidam-3.jpg", nome: "Alphas |Diária|", preco: 98.79, descricao: "Gargantilha Masculina banhada a ouro. Apropriado para passeios casuais.", categoria: "Masculino",promocao: "false", subcategoria: "Acessorio"},
    { imagem: "https://static.netshoes.com.br/produtos/kit-2-sapatenis-polo-joy-masculino-em-lona/56/FSO-0043-256/FSO-0043-256_zoom3.jpg?ts=1600149282&.jpg", nome: "Invictuss |Diária|", preco: 99.79, descricao: "SapaTênis Marron e Branco. Apropriados para quem busca esportividade e elegância.", categoria: "Masculino",promocao: "true", subcategoria: "Calcado"},
    { imagem: "https://th.bing.com/th/id/OIP.iiiPo3EWH6zmwRl1DX0VRAHaHa?rs=1&pid=ImgDetMain.jpg", nome: "Styles Event |Diária|", preco: 206.99, descricao: "Conjunto com colar e brincos cor Prata Cristais Rosa", categoria:"Feminino", promocao:"false", subcategoria: "Acessorio" },
    { imagem: "https://th.bing.com/th/id/R.6c0dbfa188e55b52ee8cb6616ce95eb9?rik=mKmhoG1GRYoa6A&pid=ImgRaw&r=0.jpg", nome: "Happy Children |Diária|", preco: 67.90, descricao: "Conjnto Infantil Veste até os 10 anos de idade Apropriado para todos os Eventos.",categoria: "Infantil", promocao: "true", subcategoria: "Roupa" },
    { imagem: "https://th.bing.com/th/id/OIP.sy7ngt89VWiNC_UO_vfnVQHaHa?rs=1&pid=ImgDetMain.jpg", nome: "Happy Children |Diária|", preco: 88.90, descricao: "Vestido Junino Infantil Veste ate os 8 anos de idade Apropriado para Festejo Juninos e Eventos temáticos. Tamanho P",categoria: "Infantil",promocao: "false", subcategoria: "Roupa"},
    { imagem: "https://th.bing.com/th/id/R.c37db1e0396b017b1fcf6bf863421f92?rik=VBSc5k5%2frz3AEg&pid=ImgRaw&r=0.jpg", nome: "Happy Children |Diária|", preco: 49.99, descricao: "Sapato infantil marron com design exalando esportividade e elegância. ",categoria: "Infantil",promocao: "true", subcategoria: "Calcado"},
    { imagem: "https://th.bing.com/th/id/R.1831f96551d6880431bd08227d19cd75?rik=OkQGPZanQb6ZSw&pid=ImgRaw&r=0.jpg", nome: "Styles Event |Diária|", preco: 89.99, descricao: "Bolsa de luxo pink perfeita para guardar acessorios e incrementar em um look casual", categoria:"Feminino", promocao:"true", subcategoria: "Acessorio" },
    { imagem: "https://imgmarketplace.lojasrenner.com.br/20001/2957/7010701777304/7510703556888/1.jpeg", nome: "ARJ Eventos |Diária|", preco: 37.99, descricao: "Bolsa de luxo preta pequena, apropriada para passeios noturnos", categoria:"Feminino", promocao:"false", subcategoria: "Acessorio" },
    { imagem: "https://images.tcdn.com.br/img/img_prod/754321/pulseira_masculina_couro_preto_folheada_a_ouro_com_garantia_2327_2_20201214013828.jpg", nome: "Alphas |Diária|", preco: 58.79, descricao: "Pulseira de Couro masculina com detalhes em ouro. Apropriado para passeios casuais.", categoria: "Masculino",promocao: "false", subcategoria: "Acessorio"},
    { imagem: "https://th.bing.com/th/id/R.0d9a2c9d4aca2f30c823895dfac450ad?rik=5HdDjveCTx7Q9Q&pid=ImgRaw&r=0.jpg", nome: "Happy Children |Diária|", preco: 85.00, descricao: "Bota infantil social marron tamanhos  ",categoria: "Infantil",promocao: "true", subcategoria: "Calcado"},
    { imagem: "https://th.bing.com/th/id/R.e30ad57520a5755067fef8cd53ad6c0d?rik=iygCkDfGdLQbVw&pid=ImgRaw&r=0.jpg", nome: "ARJ Eventos |Diária|", preco: 126.99, descricao: "Salto Preto com 13cm de altura, apropriada para passeios noturnos. Tamanho unico (37)", categoria:"Feminino", promocao:"true", subcategoria: "Calcado" },

    
];

const usuarios = [
    {nome: "Marcia Reis", email: 'usuario@gmail.com', cpf: "12345678900", endereco: "Rua Aghata 123", telefone: "11999999999", descricao:" " , senha: "123400", tipo:"Pessoal"} 
];

let carrinho = [];
    function carregarProdutos(categoria = null, subcategoria = null) {
        const container = document.getElementById("destaque");
        container.innerHTML = ""; 
    
        // Filtra os produtos com base na categoria
        let produtosFiltrados = produtos;
        if (categoria !== null && subcategoria === null) {
            produtosFiltrados = produtos.filter(produto => produto.categoria === categoria);
        }

        else if (categoria === null && subcategoria !== null) {
            produtosFiltrados = produtos.filter(produto =>produto.categoria === categoria); 
            produtosFiltrados = produtos.filter(produto => produto.promocao === subcategoria);
        }

        else if (categoria !== null && subcategoria !== null) {            
            if(subcategoria === "true"){
                produtosFiltrados = produtos.filter(produto =>produto.categoria === categoria && produto.promocao === subcategoria);
            }
            else {
                produtosFiltrados = produtos.filter(produto =>produto.categoria === categoria && produto.subcategoria === subcategoria);
            }

        }
    
        // Adiciona os produtos filtrados ao container
        produtosFiltrados.forEach(produto => {
            const divProduto = document.createElement("div");
            divProduto.classList.add("produto");
    
            const imgProduto = document.createElement("img");
            imgProduto.src = produto.imagem;
            imgProduto.alt = produto.nome;
    
            const h3Produto = document.createElement("h3");
            h3Produto.textContent = produto.nome;
    
            const pPreco = document.createElement("p");
            pPreco.textContent = `Preço: R$ ${produto.preco.toFixed(2)}`;
    
            const pDescricao = document.createElement("p");
            pDescricao.textContent = produto.descricao;

            const selectTamanho = document.createElement("select");
            selectTamanho.classList.add("select-tamanho");

            const optionDefault = document.createElement("option");
            optionDefault.textContent = "Tamanho";
            optionDefault.disabled = true;
            optionDefault.selected = true;
            selectTamanho.appendChild(optionDefault);

            // Adiciona opções de tamanho
            const tamanhos = ["P", "M", "G", "GG"];
            tamanhos.forEach(tamanho => {
                const option = document.createElement("option");
                option.value = tamanho;
                option.textContent = tamanho;
                selectTamanho.appendChild(option);
            });

    
            const btnAdicionar = document.createElement("button");
            btnAdicionar.textContent = "Adicionar ao Carrinho";
            btnAdicionar.addEventListener("click", () => { 
                if (selectTamanho.value !== "Tamanho") {
                    produto.tamanho=selectTamanho.value;
            adicionarAoCarrinho(produto); 
            alert('Produto Adicionado com sucesso.');
            } else {
            alert("Selecione um tamanho antes de adicionar ao carrinho.");
            }

                    });
    
            divProduto.appendChild(imgProduto);
            divProduto.appendChild(h3Produto);
            divProduto.appendChild(pPreco);
            divProduto.appendChild(pDescricao);
            divProduto.appendChild(selectTamanho);
            divProduto.appendChild(btnAdicionar);
    
            container.appendChild(divProduto);
        });

        document.getElementById("linkTodos").addEventListener("click", (event) => {
            event.preventDefault(); 
            carregarProdutos(null, null);
        });
        
        document.getElementById("linkFeminino").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Feminino", null); 
        });
        
        document.getElementById("linkMasculino").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Masculino", null);
        });
        
        document.getElementById("linkInfantil").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Infantil", null); 
        });

        document.getElementById("linkInfantilPromocao").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Infantil", "true"); 
        });

        document.getElementById("linkMasculinoPromocao").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Masculino", "true");
        });

        document.getElementById("linkFemininoPromocao").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Feminino", "true"); 
        });

        document.getElementById("linkPromocao").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos(null, "true"); 
        });

        document.getElementById("linkFemininoRoupa").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Feminino", "Roupa"); 
        });

        document.getElementById("linkFemininoCalcado").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Feminino", "Calcado"); 
        });

        document.getElementById("linkFemininoAcessorio").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Feminino", "Acessorio"); 
        });

        document.getElementById("linkMasculinoRoupas").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Masculino", "Roupa"); 
        });

        document.getElementById("linkMasculinoCalcados").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Masculino", "Calcado");
        });

        document.getElementById("linkMasculinoAcessorio").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Masculino", "Acessorio"); 
        });

        document.getElementById("linkInfantilRoupa").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Infantil", "Roupa"); 
        });

        document.getElementById("linkInfantilCalcado").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Infantil", "Calcado"); 
        });

        document.getElementById("linkInfantilAcessorio").addEventListener("click", (event) => {
            event.preventDefault();
            carregarProdutos("Infantil", "Acessorio"); 
        });

        document.addEventListener("DOMContentLoaded", function() {
            carregarProdutos(); 
        });
    }
    
    function adicionarAoCarrinho(produto) {
        const itemCarrinho = carrinho.find(item => item.nome === produto.nome);
        if (itemCarrinho) {
            itemCarrinho.quantidade++;
        } else {
            carrinho.push({ ...produto, quantidade: 1 });
        }
        atualizarCarrinho();
    }
    function atualizarCarrinho() {
        const carrinhoContainer = document.getElementById("itensCarrinho");
        const dias =document.getElementById("tempoaluguel").value;
        let dia=0;

        if (dias !== "Dias de alugueis"){

            alert("Quantidade de dias adicionado com sucesso!");

                    switch(dias){
                        case "tres":
                            dia=3;
                            
                        break;
                        case "cinco":
                            dia=5;
                            
                        break;
                        case "quinze":
                            dia=15;
                            
                        break;
                        case "vinte":
                            dia=20;
                            
                        break;
                        default:
                            
                            return;
                    }
                }
                else {
                    dia=1;
                }

        carrinhoContainer.innerHTML = "";
        let total = 0;
        let totalfinal = 0;
        let percentualcalcao= 0.25;
        let calcao = 0;

    
        carrinho.forEach(item => {
            const divItem = document.createElement("div");
            const imagemItem = document.createElement("img");
            imagemItem.src = item.imagem;
            imagemItem.alt = item.nome;
            divItem.appendChild(imagemItem);
    
            const nomeItem = document.createElement("p");
            nomeItem.textContent = item.nome;
            divItem.appendChild(nomeItem);

            const tamanhoItem = document.createElement("h5");
            tamanhoItem.textContent = `(Tamanho: ${item.tamanho})`;
            divItem.appendChild(tamanhoItem);

            const btnRemover = document.createElement("button");
            btnRemover.textContent = "Remover esse Item";
            btnRemover.addEventListener("click", () => removerDoCarrinho(item));
            divItem.appendChild(btnRemover);
            
            carrinhoContainer.appendChild(divItem);
    
            const precoItem = document.createElement("h3");
            precoItem.textContent = `Preço: R$ ${item.preco.toFixed(2)}`;
            divItem.appendChild(precoItem);
            
            const nomequantidade = document.createElement("h4");
            nomequantidade.textContent = "Quantidade: ";
            divItem.appendChild(nomequantidade);

            const quantidadeItem = document.createElement("input");
            quantidadeItem.type = "number";
            quantidadeItem.value = item.quantidade;
            quantidadeItem.addEventListener("input", () => atualizarQuantidade(item, quantidadeItem));
            divItem.appendChild(quantidadeItem);

            const subtotalItem = document.createElement("h3");
            const subtotal = item.preco * item.quantidade;
            subtotalItem.textContent = `Subtotal: R$ ${subtotal.toFixed(2)}`;
            divItem.appendChild(subtotalItem);
            
            total += subtotal*dia;
            calcao = total * percentualcalcao;
            totalfinal=total+calcao;

            });
            
            
            document.getElementById("totalCarrinho").textContent = `(Calção é 25% do valor total) Valor do Calção : R$ ${calcao.toFixed(2)} + (produto * dias de alugueis) Total: R$ ${total.toFixed(2)} = | Valor Final: R$ ${totalfinal.toFixed(2)} `;
            document.getElementById("totalCarrinhofinal").textContent = `(Calção é 25% do valor total) Valor Calção : R$ ${calcao.toFixed(2)}+ (produto * dias de alugueis) Total: R$ ${total.toFixed(2)} = | Valor Final: R$ ${totalfinal.toFixed(2)}`;

        }

        function Faq(){
        const pergunta=document.getElementById("duvida").value;
        if(!pergunta){
            alert("Campo vazio. Digite sua duvida.");
        }
        else if(pergunta){
            document.getElementById("duvidas").textContent = `(${pergunta})`;
            limparInput();
            
        }
        }

        function limparInput() {
            document.getElementById("duvida").value = "";
        }

         function atualizarQuantidade(item, inputQuantidade) {
            const novaQuantidade = parseInt(inputQuantidade.value);
            if (novaQuantidade <= 0) {
                removerDoCarrinho(item);
                return;
            }
            item.quantidade = novaQuantidade;
            atualizarCarrinho();
            }
            
            function removerDoCarrinho(item) {
            carrinho = carrinho.filter(i => i !== item);
            atualizarCarrinho();
            }
            
            function abrirCarrinho() {
            document.getElementById("carrinhoOverlay").style.display = "block";
            }
            
            function fecharCarrinho() {
            document.getElementById("carrinhoOverlay").style.display = "none";
            }
            
            function limparCarrinho() {
            carrinho = [];
            atualizarCarrinho();
            }

            function concluirAluguel() {

                const dias=document.getElementById("tempoaluguel").value;
                let dia=0;


                if (carrinho.length === 0 || dias === "Dias de alugueis") {
                    if (dias === "Dias de alugueis"){
                        alert("Para prosseguir selecione a quantidade de dias válidos");
                        return;
                    }
                    else{
                        alert("O carrinho está vazio. Adicione itens antes de concluir a compra.");
                    return;
                    }
                }
                
                else if (dias !== "Dias de alugueis"){
                    switch(dias){
                        case "tres":
                            dia=3;
                        break;
                        case "cinco":
                            dia=5;
                        break;
                        case "quinze":
                            dia=15;
                        break;
                        case "vinte":
                            dia=20;
                        break;
                        default:
                            alert("Para prosseguir selecione a quantidade de dias válidos");
                            return;
                    }
                }
            
                let resumo = "Resumo do Aluguel:\n\n";
                let total = 0;
                let totalfinal = 0;
                let percentual = 0.25;
                let calcao =0;
            
                carrinho.forEach(item => {
                    resumo += `- Nome: ${item.nome}\n`;
                    resumo += `  Tamanho: ${item.tamanho}\n`;
                    resumo += `  Quantidade: ${item.quantidade}\n`;
                    resumo += `  Preço Unitário: R$ ${item.preco.toFixed(2)}\n`;
                    resumo += `  Subtotal: R$ ${(item.preco * item.quantidade).toFixed(2)}\n\n`;
                    
                    total += item.preco * item.quantidade;
                    resumo += `  Calção: R$ ${(total * percentual).toFixed(2)}\n\n`;
                    resumo += `  Dias de Alugueis: ${dia}\n\n`;
                    calcao=total*percentual;
                     totalfinal=total+calcao*dia;
                });
               
                resumo += `(Total + Calção (*dias de alugueis) ) Valor Final: R$ ${totalfinal.toFixed(2)}`;

            const dadosClienteJSON = localStorage.getItem("dadosCliente");


            // Se os dados do cliente existirem no localStorage
             if (dadosClienteJSON) {
                const txt="Dados do Cliente:";
                const txt1="-------------------------------------------------------------------------------------";
                const dadosCliente = JSON.parse(dadosClienteJSON);

                // Geração do PDF com jsPDF
                const { jsPDF } = window.jspdf;
                const doc = new jsPDF();
                
                const pageWidth = doc.internal.pageSize.width;
                const pageHeight = doc.internal.pageSize.height;
                const marginY = 10;
                let posY = marginY + 40; // Espaço para logo e primeiros textos
                
                // Adicionando os dados do cliente no PDF
                doc.text(` ${txt}`, 10, posY);
                posY += 10;
                doc.text(` ${txt1}`, 10, posY);
                posY += 10;
                doc.text(`Nome: ${dadosCliente.nome}`, 10, posY);
                posY += 10;
                doc.text(`CPF: ${dadosCliente.cpfcliente}`, 10, posY);
                posY += 10;
                doc.text(`Endereço: ${dadosCliente.endereco}`, 10, posY);
                posY += 10;
                doc.text(`Telefone: ${dadosCliente.telefone}`, 10, posY);
                posY += 20;
                doc.text(` ${txt1}`, 10, posY);
                posY += 20;
                
                // Adicionando o resumo da compra no PDF (quebra de linha automática)
                const linhasResumo = doc.splitTextToSize(resumo, pageWidth - 20);
                linhasResumo.forEach((linha) => {
                    if (posY + 10 > pageHeight - marginY) {
                        doc.addPage();
                        posY = marginY; // Resetar a posição na nova página
                    }
                    doc.text(linha, 10, posY);
                    posY += 10;
                });
                
                // Observação em vermelho (quebra de página se necessário)
                const texto = "Observação: Compareça a uma das nossas lojas com o CPF e este documento no prazo máximo de 24 horas para a retirada dos produtos previamente reservados.";
                const textoQuebrado = doc.splitTextToSize(texto, pageWidth - 20);
                
                if (posY + 20 > pageHeight - marginY) {
                    doc.addPage();
                    posY = marginY;
                }
                
                doc.setTextColor(255, 0, 0); // Define cor vermelha
                textoQuebrado.forEach((linha) => {
                    if (posY + 10 > pageHeight - marginY) {
                        doc.addPage();
                        posY = marginY;
                    }
                    doc.text(linha, 10, posY);
                    posY += 10;
                });
                
                // Salva o PDF com o nome 'Resumo_Aluguel.pdf'
                doc.save("Resumo_Aluguel.pdf");
                
                // Limpa os dados do cliente do localStorage
                localStorage.removeItem("dadosCliente");
                
                alert("Dados do cliente e resumo da compra salvos em PDF.");
                
// Salva o PDF com o nome 'Resumo_Aluguel.pdf'
// doc.save("Resumo_Aluguel.pdf");

// // Limpa os dados do cliente do localStorage
// localStorage.removeItem("dadosCliente");

// alert("Dados do cliente e resumo da compra salvos em PDF.");

            //     const dadosCliente = JSON.parse(dadosClienteJSON);

            //     // Geração do PDF com jsPDF
            //     const { jsPDF } = window.jspdf;
            //     const doc = new jsPDF();

            // const pageHeight = doc.internal.pageSize.height;
            
            // const texto = "Observação: Compareça a uma das nossas lojas com o CPF e este documento no prazo máximo de 24 horas para a retirada dos produtos previamente reservados.";
            // const textoQuebrado = doc.splitTextToSize(texto, 180);
            // const posY = pageHeight - 20; 
                
            //     // Adicionando os dados do cliente no PDF
            //     doc.text(`Nome: ${dadosCliente.nome}`, 10, 10);
            //     doc.text(`CPF: ${dadosCliente.cpfcliente}`, 10, 20);
            //     doc.text(`Endereço: ${dadosCliente.endereco}`, 10, 30);
            //     doc.text(`Telefone: ${dadosCliente.telefone}`, 10, 40);

            //     // Adicionando o resumo da compra no PDF
            //     doc.text(resumo, 10, 50);
            //     doc.setTextColor(255, 0, 0);
            //     doc.text(textoQuebrado, 10, posY);
            

            //     // Salva o PDF com o nome 'Resumo_Compra.pdf'
            //     doc.save("Resumo_Aluguel.pdf");

            //     // Limpa os dados do cliente do localStorage
            //     localStorage.removeItem("dadosCliente");

            //     alert("Dados do cliente e resumo da compra salvos em PDF.");
            } else {
                alert("Faça o login para concluir o cadastro!");
                window.location.href = "Loginluxxus.html";
            }

                carrinho = [];
                atualizarCarrinho();
            }
                
            
    
        
            document.getElementById("abrirCarrinho").addEventListener("click", abrirCarrinho);
            document.getElementById("btnConcluir").addEventListener("click", concluirAluguel);

            document.addEventListener("DOMContentLoaded", function() {
            carregarProdutos();
            });


        function buscarProdutos(termospesquisa=null) {
            let barraDePesquisa = document.getElementById('search-bar').value.toLowerCase(); 
            const resultadosContainer = document.getElementById('destaque'); 
            
            if(termospesquisa !== null){
                // alert(termospesquisa);
                barraDePesquisa = termospesquisa;
            }

            if(barraDePesquisa.toLowerCase() === "promocao" || 
                    barraDePesquisa.toLowerCase() === "promoção" || 
                    barraDePesquisa.toLowerCase() === "promoçôes"){
            // alert(barraDePesquisa);
                   barraDePesquisa = "true";
                //    alert(barraDePesquisa);
            }
        
            
            resultadosContainer.innerHTML = ""; 
        
            const resultados = produtos.filter(produto => 
                produto.nome.toLowerCase().includes(barraDePesquisa) || 
                produto.descricao.toLowerCase().includes(barraDePesquisa) || 
                produto.promocao.toLowerCase().includes(barraDePesquisa)
            );

            if (resultados.length > 0) {
                resultados.forEach(produto => {
                    const produtoDiv = document.createElement('div');
                    produtoDiv.classList.add('produto');
            
                    const imgProduto = document.createElement('img');
                    imgProduto.src = produto.imagem;
                    imgProduto.alt = produto.nome;
                    imgProduto.classList.add('produto-imagem');
            
                    const h3Produto = document.createElement('h3');
                    h3Produto.textContent = produto.nome;
                    h3Produto.classList.add('produto-nome');
            
                    const pDescricao = document.createElement('p');
                    pDescricao.textContent = produto.descricao;
                    pDescricao.classList.add('produto-descricao');
            
                    const pPreco = document.createElement('p');
                    pPreco.textContent = `R$ ${produto.preco.toFixed(2)}`;
                    pPreco.classList.add('produto-preco');
            
                    
                    const selectTamanho = document.createElement('select');
                    selectTamanho.id = `tamanho-${produto.id}`;
                    selectTamanho.classList.add('select-tamanho');
            
                    const optionDefault = document.createElement('option');
                    optionDefault.textContent = 'Tamanho';
                    optionDefault.disabled = true;
                    optionDefault.selected = true;
                    selectTamanho.appendChild(optionDefault);
            
                    const tamanhos = ['P', 'M', 'G', 'GG'];
                    tamanhos.forEach(tamanho => {
                        const option = document.createElement('option');
                        option.value = tamanho;
                        option.textContent = tamanho;
                        selectTamanho.appendChild(option);
                    });
            
                    
                    const btnAdicionar = document.createElement('button');
                    btnAdicionar.textContent = 'Adicionar ao Carrinho';
                    btnAdicionar.addEventListener('click', () => {
                        if (selectTamanho.value !== 'Tamanho') {
                            produto.tamanho = selectTamanho.value;
                            adicionarAoCarrinho(produto);
                            alert('Produto Adicionado com sucesso.'); 
                        } else {
                            alert('Selecione um tamanho antes de adicionar ao carrinho.');
                        }
                    });
            
                    
                    produtoDiv.appendChild(imgProduto);
                    produtoDiv.appendChild(h3Produto);
                    produtoDiv.appendChild(pDescricao);
                    produtoDiv.appendChild(pPreco);
                    produtoDiv.appendChild(selectTamanho);
                    produtoDiv.appendChild(btnAdicionar);
            
                    resultadosContainer.appendChild(produtoDiv);
                });
            } else {
                
                resultadosContainer.innerHTML = `<p id="Resultado">Nenhum produto encontrado.</p>`;
            }
            
        
            
        document.getElementById('search-button').addEventListener('click', buscarProdutos);


    }

    // Conceito de Gui

    function ativarMicrofone() {
        if (!('webkitSpeechRecognition' in window)) {
            alert('Seu navegador não suporta reconhecimento de voz.');
            return;
        }

        const recognition = new webkitSpeechRecognition();
        recognition.lang = 'pt-BR'; // Define o idioma para português
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        recognition.onstart = function () {
            document.getElementById('voice-button').textContent = '🎤 Ouvindo...';
        };

        recognition.onresult = function (event) {
            let texto = event.results[0][0].transcript;
            texto = texto.replace(/\.$/, "");
            document.getElementById('search-bar').value = texto;
            buscarProdutos(texto); // Aciona a busca automaticamente
        };

        recognition.onerror = function () {
            alert('Não foi possível reconhecer a fala.');
        };

        recognition.onend = function () {
            document.getElementById('voice-button').textContent = '🎤 Falar';
        };

        recognition.start();
    }
    
    function Login() {
        const senha=document.getElementById("senha").value;
        const email=document.getElementById("email").value;

        if (!senha || !email){
            alert("Preencha corretamente todos os campos");
            return;
        }
        if (!(email.includes("@") && email.includes(".") ) ){
            alert("Email invalido");
            return;
        }
        const usuarioIndex = usuarios.findIndex(user => user.senha === senha || user.email === email );
        if (usuarioIndex !== -1) {
            // alert("teste"+ usuarios[usuarioIndex]);
                
            const dadoscliente = {
                    nome: usuarios[usuarioIndex].nome,
                    cpfcliente: usuarios[usuarioIndex].cpf,
                    endereco: usuarios[usuarioIndex].endereco,
                    telefone: usuarios[usuarioIndex].telefone
                };

                localStorage.setItem('dadosCliente', JSON.stringify(dadoscliente));

            alert(`Usuário Logado com sucesso!`);
            window.location.href = "Luxxus.html";
            
        } else {
            alert("Usuário não encontrado!");
        }


    }

      function recuperarCadastro() {
        const cpfrecuperacao=document.getElementById("cpfrecuperar").value;
        const emailatual=document.getElementById("email").value;
        const telefoneatual=document.getElementById("telefone").value;
        const senhaatual=document.getElementById("senha").value;
        const cofirmacaosenha=document.getElementById("confirmar-senha").value;
        
    
        if (!emailatual || !cpfrecuperacao  || !telefoneatual || !senhaatual || !cofirmacaosenha) {
            alert("Por favor, preencha todos os campos obrigatórios.");
            return;
        }
        if (senhaatual.length < 6 ){
            alert("As Senha devem ter no minimo 6 caracteres.");
            return;
        }
        if ( senhaatual !== cofirmacaosenha) {
            alert("As senhas não coincidem.");
            return;
        }

        if (!(emailatual.includes("@") && emailatual.includes(".") ) ){
            alert("Email invalido");
            return;
        }
        if (!(telefoneatual.length === 11 && telefoneatual >= 50000000000 && telefoneatual <= 99999999999) ){
            alert("Telefone inválidos");
            return;
        }

        const usuarioIndex = usuarios.findIndex(user => user.cpf === cpfrecuperacao );

    
        if (usuarioIndex !== -1) {

            usuarios[usuarioIndex].email=emailatual;
            usuarios[usuarioIndex].telefone=telefoneatual;
            usuarios[usuarioIndex].senha=senhaatual;
            alert(`Usuário atualizado com sucesso!\nTelefone: ${usuarios[usuarioIndex].telefone}\nEmail: ${usuarios[usuarioIndex].email}\n senha:${usuarios[usuarioIndex].senha }\n tamanho:${usuarios.length}`);
            window.location.href = "Luxxus.html";
        } else {
            alert("Usuário não encontrado!");
        }

      }

    function cadastrarUsuario() {
        
        const tipoCadastro = document.getElementById("empresa-pessoafisica").value;
        const nome = document.getElementById("nome").value;
        const email = document.getElementById("email").value;
        const cpf = document.getElementById("cpf").value;
        const endereco = document.getElementById("endereco").value;
        const telefone = document.getElementById("telefone").value;
        const descricao = document.getElementById("descricao").value;
        const senha = document.getElementById("senha").value;
        const confirmarSenha = document.getElementById("confirmar-senha").value;
    
        
        if (!tipoCadastro || !nome || !email || !cpf || !endereco || !telefone || !senha || !confirmarSenha) {
            alert("Por favor, preencha todos os campos obrigatórios.");
            return;
        }
    
        
        if (senha.length < 6 ){
            alert("As Senha devem ter no minimo 6 caracteres.");
            return;
        }
        if (senha !== confirmarSenha) {
            alert("As senhas não coincidem.");
            return;
        }

        if (!(email.includes("@") && email.includes(".") ) ){
            alert("Email invalido");
            return;
        }
        

        if(cpf.length === 11){
        if (! (cpf >= "00000000191" && cpf <= "99999999999") ){
            alert("Cpf inválidos");
            return;
        }  
        }
        
        if(cpf.length === 14){

            if(! (cpf >= "00000000000191" && cpf <= "99999999999999")) {
                alert(" Cnpj inválidos");
                return;
            }
        }

                                                  
        if (!(telefone.length === 11 && telefone >= 50000000000 && telefone <= 99999999999) ){
            alert("Telefone inválidos");
            return;
        }

        

        
        const usuarioExistente = usuarios.find(user => user.email === email || user.cpf === cpf);
    
        if (usuarioExistente) {
            alert("Usuário já cadastrado.");
            return;
        }
        
    
        
        const usuario = {
            
            nome: nome,
            email: email,
            cpf: cpf,
            endereco: endereco,
            telefone: telefone,
            descricao: tipoCadastro === "Empresa" ? descricao : "", 
            senha: senha,
            tipoCadastro: tipoCadastro
        };
    
        

        usuarios.push(usuario);
        
        alert("Cadastro realizado com sucesso!");
    
        
        document.getElementById("nome").value = "";
        document.getElementById("email").value = "";
        document.getElementById("cpf").value = "";
        document.getElementById("endereco").value = "";
        document.getElementById("telefone").value = "";
        document.getElementById("descricao").value = "";
        document.getElementById("senha").value = "";
        document.getElementById("confirmar-senha").value = "";
        window.location.href = "Luxxus.html";
    }
    
   